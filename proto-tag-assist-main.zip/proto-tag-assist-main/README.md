# ProtoTag Health Companion

Crie um aplicativo mobile chamado "ProtoTag", voltado para monitoramento inteligente de próteses externas de membros inferiores em ortopedia pediátrica, com foco em clareza clínica, tomada de decisão rápida e experiência profissional.

O app deve ser moderno, minimalista, altamente funcional e orientado a dados, com design limpo (estilo healthcare premium), priorizando legibilidade, hierarquia visual clara e baixo ruído cognitivo.

### OBJETIVO PRINCIPAL

Permitir a leitura sob demanda de um adesivo biomédico com sensores de pressão via NFC, interpretar esses dados com inteligência adaptativa e fornecer um indicador clínico confiável que antecipe a necessidade de ajuste ou troca da prótese.

---

### FUNCIONALIDADES PRINCIPAIS

#### 1. CONEXÃO NFC

- Leitura rápida via NFC passivo (sem bateria no adesivo)

- Feedback imediato após leitura (ex: “Leitura realizada com sucesso”)

- Cada adesivo vinculado a uma única prótese/paciente

- Histórico de leituras organizado automaticamente

---

#### 2. FASE DE CALIBRAÇÃO (7 DIAS)

- Ao iniciar um novo paciente:

  - O sistema entra automaticamente em modo de calibração

  - Duração: 7 dias

- Durante esse período:

  - Detectar automaticamente padrões de uso:

    - Uso ativo (deambulação)

    - Repouso

    - Ausência da prótese

  - Construir baseline individual adaptativo

- Interface deve mostrar:

  - Progresso da calibração (ex: “Dia 3 de 7”)

  - Feedback simples: “Aprendendo padrão do paciente”

---

#### 3. ÍNDICE DE INTEGRIDADE PROTÉTICA (IIP)

- Após calibração:

  - Exibir um score contínuo de 0 a 100

- O IIP deve ser calculado com base em:

  - Variabilidade de pressão (desvio padrão espacial)

  - Assimetria de carga

  - Presença de hotspots persistentes

  - Mudanças no padrão temporal

- UX:

  - Mostrar o número em destaque (ex: 82)

  - Código de cores:

    - Verde (bom)

    - Amarelo (atenção)

    - Vermelho (crítico)

---

#### 4. DASHBOARD PRINCIPAL

Tela única, limpa e altamente informativa contendo:

- IIP em destaque

- Gráfico de evolução do IIP com opções de visualização:

  - 24 horas

  - 7 dias (semana)

  - 30 dias (mês)

  - 12 meses (ano)

- Indicadores visuais simples:

  - Tendência (↑ ↓ →)

  - Status atual (Estável, Atenção, Crítico)

---

#### 5. INTELIGÊNCIA PREDITIVA

- Detectar automaticamente:

  - Anomalias

  - Tendência de piora

- Gerar previsões como:

  - “Queda abaixo do nível crítico em ~10 dias”

- Alertas devem ser:

  - Diretos

  - Curtos

  - Acionáveis

Exemplo:

  - “Risco de ajuste necessário em breve”

  - “Hotspot persistente detectado”

---

#### 6. DETECÇÃO DE HOTSPOTS E RISCO CUTÂNEO

- Identificar regiões com:

  - Pressão elevada

  - Longo tempo de exposição

- Sinalizar risco de lesão por pressão

- Exibir:

  - Alertas simples

  - Destaque visual no app

---

#### 7. MODO AVANÇADO (PROFISSIONAL)

Acesso opcional (não intrusivo):

- Exibir dados brutos dos sensores

- Gráfico com:

  - 6 linhas (uma para cada sensor)

  - Valores reais de pressão

- Mesmas escalas:

  - 24h, semana, mês, ano

- Interface mais técnica, mas ainda organizada

---

#### 8. PERFIL DO PACIENTE

- Informações básicas:

  - Nome

  - Idade

  - Lado da prótese

  - Data de início

- Histórico de uso

- Vínculo com adesivo

---

#### 9. RELATÓRIOS

- Gerar relatório exportável contendo:

  - Evolução do IIP

  - Eventos relevantes

  - Alertas gerados

- Formato limpo e clínico (PDF ou similar)

---

### DESIGN E EXPERIÊNCIA (UX/UI)

- Estilo:

  - Minimalista

  - Clínico

  - Profissional

- Paleta:

  - Branco, cinza claro, azul suave

  - Vermelho/amarelo apenas para alertas

- Tipografia:

  - Alta legibilidade

- Layout:

  - Dashboard único como foco principal

- Interação:

  - Fluida, sem excesso de cliques

- Linguagem:

  - Clara, objetiva e médica

---

### COMPORTAMENTO INTELIGENTE

- Sistema adaptativo ao paciente

- Aprendizado contínuo

- Detecção de padrões circadianos

- Separação automática de contextos:

  - Uso

  - Repouso

  - Não uso

---

### DIFERENCIAL DO PRODUTO

O ProtoTag não é apenas um leitor de sensores — ele é um sistema de suporte à decisão clínica que transforma dados brutos de pressão em recomendações práticas, antecipando problemas antes que se tornem clínicos.

---

### RESULTADO ESPERADO

Gerar um app completo com:

- Fluxo de onboarding

- Dashboard funcional

- Simulação de dados (caso necessário)

- Interface polida e realista

- Estrutura pronta para implementação real

Priorizar uma experiência que transmita confiança clínica, precisão e simplicidade.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://proto-tag-assist.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7988d6f7-dfc8-48bc-bde0-60dc757d626b).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
