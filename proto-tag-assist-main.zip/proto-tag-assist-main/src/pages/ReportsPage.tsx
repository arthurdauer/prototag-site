import { FileText, Download, ChevronRight } from 'lucide-react';
import { mockPatient, mockAlerts } from '@/lib/mockData';

const reports = [
  { id: '1', title: 'Relatório Semanal', date: '07/04/2026', period: '31/03 - 06/04' },
  { id: '2', title: 'Relatório Mensal', date: '01/04/2026', period: 'Março 2026' },
  { id: '3', title: 'Relatório de Calibração', date: '08/03/2026', period: 'Fase inicial' },
];

export default function ReportsPage() {
  return (
    <div className="pb-24 max-w-lg mx-auto px-4 pt-4">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-lg font-bold text-foreground">Relatórios</h1>
          <p className="text-xs text-muted-foreground">{mockPatient.name}</p>
        </div>
        <button className="flex items-center gap-1.5 text-xs font-medium text-primary bg-primary/10 px-3 py-2 rounded-lg">
          <Download className="w-3.5 h-3.5" />
          Gerar PDF
        </button>
      </div>

      {/* Report list */}
      <div className="space-y-2 mb-6">
        {reports.map(r => (
          <div key={r.id} className="glass-card p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">{r.title}</p>
              <p className="text-xs text-muted-foreground">{r.period} · {r.date}</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="glass-card p-5">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-3">
          Resumo do Período Atual
        </p>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">IIP médio</span>
            <span className="text-sm font-semibold text-foreground">81</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Tendência</span>
            <span className="text-sm font-semibold text-clinical-yellow">Queda leve ↓</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Alertas gerados</span>
            <span className="text-sm font-semibold text-foreground">{mockAlerts.length}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Desvios detectados</span>
            <span className="text-sm font-semibold text-clinical-yellow">2 padrões</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Dias monitorados</span>
            <span className="text-sm font-semibold text-foreground">41</span>
          </div>
        </div>
      </div>
    </div>
  );
}
