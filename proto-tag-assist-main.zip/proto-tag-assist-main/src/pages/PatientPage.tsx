import { mockPatient, mockReadings24h } from '@/lib/mockData';
import CalibrationCard from '@/components/CalibrationCard';
import { mockCalibrationPatient } from '@/lib/mockData';
import { User, Calendar, Footprints, Tag, Clock } from 'lucide-react';

export default function PatientPage() {
  const p = mockPatient;
  const totalReadings = mockReadings24h.length;

  return (
    <div className="pb-24 max-w-lg mx-auto px-4 pt-4">
      <div className="mb-5">
        <h1 className="text-lg font-bold text-foreground">Perfil do Paciente</h1>
      </div>

      {/* Patient info */}
      <div className="glass-card p-5 mb-3">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-xl font-bold text-primary">{p.name.charAt(0)}</span>
          </div>
          <div>
            <p className="text-lg font-bold text-foreground">{p.name}</p>
            <p className="text-sm text-muted-foreground">{p.age} anos</p>
          </div>
        </div>

        <div className="space-y-3">
          <InfoRow icon={<Footprints className="w-4 h-4" />} label="Lado da prótese" value={`Membro inferior ${p.side}`} />
          <InfoRow icon={<Calendar className="w-4 h-4" />} label="Início do monitoramento" value={p.startDate.toLocaleDateString('pt-BR')} />
          <InfoRow icon={<Tag className="w-4 h-4" />} label="Adesivo vinculado" value={p.stickerSerial} />
          <InfoRow icon={<Clock className="w-4 h-4" />} label="Leituras realizadas" value={`${totalReadings} leituras`} />
        </div>
      </div>

      {/* Calibration example */}
      <div className="mb-3">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2 px-1">
          Exemplo: Paciente em calibração
        </p>
        <CalibrationCard patient={mockCalibrationPatient} />
      </div>

      {/* Usage history */}
      <div className="glass-card p-5">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-3">
          Padrão de Uso (Últimas 24h)
        </p>
        <div className="grid grid-cols-3 gap-2">
          <StatBlock label="Ativo" value="62%" sub="~8h" />
          <StatBlock label="Repouso" value="30%" sub="~4h" />
          <StatBlock label="Sem uso" value="8%" sub="~1h" />
        </div>
      </div>
    </div>
  );
}

function InfoRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="text-muted-foreground">{icon}</div>
      <div className="flex-1">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium text-foreground">{value}</p>
      </div>
    </div>
  );
}

function StatBlock({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="text-center p-3 bg-secondary rounded-lg">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-lg font-bold text-foreground">{value}</p>
      <p className="text-[10px] text-muted-foreground">{sub}</p>
    </div>
  );
}
