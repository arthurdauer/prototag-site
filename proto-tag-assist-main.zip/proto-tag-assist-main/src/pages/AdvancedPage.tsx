import SensorChart from '@/components/SensorChart';
import { mockReadings24h } from '@/lib/mockData';

export default function AdvancedPage() {
  const latest = mockReadings24h[mockReadings24h.length - 1];
  const sensorLabels = ['S1 - Anterior', 'S2 - Lateral', 'S3 - Posterior', 'S4 - Medial', 'S5 - Distal', 'S6 - Proximal'];

  return (
    <div className="pb-24 max-w-lg mx-auto px-4 pt-4">
      <div className="mb-5">
        <h1 className="text-lg font-bold text-foreground">Modo Avançado</h1>
        <p className="text-xs text-muted-foreground">Dados brutos dos sensores de pressão</p>
      </div>

      {/* Current values */}
      <div className="glass-card p-4 mb-3">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-3">
          Leitura Atual
        </p>
        <div className="grid grid-cols-3 gap-2">
          {latest?.sensors.map((v, i) => (
            <div key={i} className="text-center p-2 bg-secondary rounded-lg">
              <p className="text-[10px] text-muted-foreground">{sensorLabels[i].split(' - ')[0]}</p>
              <p className="text-lg font-bold text-foreground">{Math.round(v)}</p>
              <p className="text-[10px] text-muted-foreground">kPa</p>
            </div>
          ))}
        </div>
      </div>

      {/* Sensor Chart */}
      <SensorChart />

      {/* Stats */}
      <div className="glass-card p-4 mt-3">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-3">
          Estatísticas (24h)
        </p>
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-secondary rounded-lg">
            <p className="text-xs text-muted-foreground">Desvio padrão espacial</p>
            <p className="text-lg font-bold text-foreground">8.3 <span className="text-xs font-normal text-muted-foreground">kPa</span></p>
          </div>
          <div className="p-3 bg-secondary rounded-lg">
            <p className="text-xs text-muted-foreground">Assimetria de carga</p>
            <p className="text-lg font-bold text-foreground">12% <span className="text-xs font-normal text-muted-foreground">Δ</span></p>
          </div>
          <div className="p-3 bg-secondary rounded-lg">
            <p className="text-xs text-muted-foreground">Tempo ativo</p>
            <p className="text-lg font-bold text-foreground">8.2 <span className="text-xs font-normal text-muted-foreground">horas</span></p>
          </div>
          <div className="p-3 bg-secondary rounded-lg">
            <p className="text-xs text-muted-foreground">Pico máximo</p>
            <p className="text-lg font-bold text-foreground">72 <span className="text-xs font-normal text-muted-foreground">kPa</span></p>
          </div>
        </div>
      </div>
    </div>
  );
}
