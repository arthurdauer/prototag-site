import NFCReader from '@/components/NFCReader';
import IIPScore from '@/components/IIPScore';
import IIPChart from '@/components/IIPChart';
import AlertsList from '@/components/AlertsList';
import HotspotIndicator from '@/components/HotspotIndicator';
import PredictiveInsight from '@/components/PredictiveInsight';
import { currentIip, mockReadings24h, mockAlerts, mockPatient } from '@/lib/mockData';

export default function Dashboard() {
  return (
    <div className="pb-24 max-w-lg mx-auto px-4 pt-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-lg font-bold text-foreground">ProtoTag</h1>
          <p className="text-xs text-muted-foreground">
            {mockPatient.name} · {mockPatient.age} anos · Lado {mockPatient.side}
          </p>
        </div>
        <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
          <span className="text-sm font-semibold text-primary">
            {mockPatient.name.charAt(0)}
          </span>
        </div>
      </div>

      {/* NFC Reader */}
      <NFCReader />

      {/* IIP Score */}
      <div className="mt-4">
        <IIPScore score={currentIip} readings={mockReadings24h} />
      </div>

      {/* Predictive Insight */}
      <div className="mt-3">
        <PredictiveInsight />
      </div>

      {/* IIP Chart */}
      <div className="mt-3">
        <IIPChart />
      </div>

      {/* Pattern Deviations */}
      <div className="mt-3">
        <HotspotIndicator />
      </div>

      {/* Alerts */}
      <div className="mt-3">
        <AlertsList alerts={mockAlerts} />
      </div>
    </div>
  );
}
