import { useState, useEffect } from 'react';
import { Activity, Brain, BarChart3, Check } from 'lucide-react';
import { useAppState } from '@/lib/appState';
import { mockPatient } from '@/lib/mockData';

const messages = [
  { day: 1, text: 'Coletando padrão de uso', sub: 'Registrando primeiros dados de pressão' },
  { day: 2, text: 'Identificando ciclos de atividade', sub: 'Detectando períodos de uso e repouso' },
  { day: 3, text: 'Aprendendo comportamento do paciente', sub: 'Analisando padrões circadianos' },
  { day: 4, text: 'Refinando baseline individual', sub: 'Construindo referência personalizada' },
  { day: 5, text: 'Mapeando distribuição de carga', sub: 'Identificando padrão normal de pressão' },
  { day: 6, text: 'Estabelecendo referência individual', sub: 'Finalizando modelo preditivo' },
  { day: 7, text: 'Calibração concluída', sub: 'Monitoramento ativo iniciado' },
];

export default function CalibrationScreen() {
  const { calibrationDay, setCalibrationDay, setCalibrationComplete } = useAppState();
  const [showComplete, setShowComplete] = useState(false);

  const currentMessage = messages[Math.min(calibrationDay - 1, 6)];
  const progress = (calibrationDay / 7) * 100;

  // Simulate day progression for demo
  useEffect(() => {
    const timer = setInterval(() => {
      setCalibrationDay(Math.min(calibrationDay + 1, 7));
    }, 4000);
    return () => clearInterval(timer);
  }, [calibrationDay]);

  useEffect(() => {
    if (calibrationDay >= 7) {
      setShowComplete(true);
      const t = setTimeout(() => setCalibrationComplete(true), 3000);
      return () => clearTimeout(t);
    }
  }, [calibrationDay]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 bg-background">
      <div className="flex flex-col items-center text-center max-w-sm w-full">
        {/* Icon */}
        <div
          className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 transition-all duration-500 ${
            showComplete ? 'bg-clinical-green/10' : 'bg-primary/10'
          }`}
        >
          {showComplete ? (
            <Check className="w-9 h-9 text-clinical-green" />
          ) : (
            <Brain className="w-9 h-9 text-primary animate-pulse" />
          )}
        </div>

        {/* Title */}
        <h1 className="text-xl font-bold text-foreground mb-1">
          {showComplete ? 'Calibração Concluída' : 'Fase de Calibração'}
        </h1>
        <p className="text-sm text-muted-foreground mb-6">
          {mockPatient.name} · {mockPatient.age} anos
        </p>

        {/* Progress */}
        <div className="w-full glass-card p-6 mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-foreground">
              Dia {Math.min(calibrationDay, 7)} de 7
            </span>
            <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-clinical-blue-light text-clinical-blue">
              {showComplete ? 'Completo' : 'Em progresso'}
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${
                showComplete ? 'bg-clinical-green' : 'bg-primary'
              }`}
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Current message */}
        <div className="w-full glass-card p-5 mb-4">
          <div className="flex items-center gap-3">
            <Activity className="w-5 h-5 text-primary flex-shrink-0" />
            <div className="text-left">
              <p className="text-sm font-medium text-foreground">{currentMessage.text}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{currentMessage.sub}</p>
            </div>
          </div>
        </div>

        {/* Info cards */}
        {!showComplete && (
          <div className="w-full grid grid-cols-3 gap-2">
            <div className="text-center p-3 bg-secondary rounded-xl">
              <Activity className="w-4 h-4 text-primary mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Uso ativo</p>
              <p className="text-xs font-semibold text-foreground">Detectando</p>
            </div>
            <div className="text-center p-3 bg-secondary rounded-xl">
              <BarChart3 className="w-4 h-4 text-primary mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Repouso</p>
              <p className="text-xs font-semibold text-foreground">Detectando</p>
            </div>
            <div className="text-center p-3 bg-secondary rounded-xl">
              <Brain className="w-4 h-4 text-primary mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Baseline</p>
              <p className="text-xs font-semibold text-foreground">Construindo</p>
            </div>
          </div>
        )}

        {showComplete && (
          <p className="text-sm text-clinical-green font-medium">
            Monitoramento ativo iniciado
          </p>
        )}
      </div>
    </div>
  );
}
