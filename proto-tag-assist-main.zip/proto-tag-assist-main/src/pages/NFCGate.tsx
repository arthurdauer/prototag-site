import { useState } from 'react';
import { Nfc, Loader2, Check, Smartphone } from 'lucide-react';
import { useAppState } from '@/lib/appState';

type GateState = 'waiting' | 'reading' | 'success';

export default function NFCGate() {
  const [state, setState] = useState<GateState>('waiting');
  const { setNfcConnected } = useAppState();

  const handleTap = () => {
    if (state !== 'waiting') return;
    setState('reading');
    setTimeout(() => {
      setState('success');
      setTimeout(() => {
        setNfcConnected(true);
      }, 1500);
    }, 2000);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 bg-background">
      <div className="flex flex-col items-center text-center max-w-sm">
        {/* Icon */}
        <div
          className={`w-24 h-24 rounded-full flex items-center justify-center mb-8 transition-all duration-500 ${
            state === 'success'
              ? 'bg-clinical-green/10'
              : state === 'reading'
              ? 'bg-primary/10 animate-pulse'
              : 'bg-primary/10'
          }`}
        >
          {state === 'reading' ? (
            <Loader2 className="w-10 h-10 text-primary animate-spin" />
          ) : state === 'success' ? (
            <Check className="w-10 h-10 text-clinical-green" />
          ) : (
            <Nfc className="w-10 h-10 text-primary" />
          )}
        </div>

        {/* Text */}
        <h1 className="text-xl font-bold text-foreground mb-2">
          {state === 'success'
            ? 'Adesivo conectado com sucesso'
            : state === 'reading'
            ? 'Lendo adesivo...'
            : 'ProtoTag'}
        </h1>
        <p className="text-sm text-muted-foreground mb-8">
          {state === 'success'
            ? 'Iniciando monitoramento...'
            : state === 'reading'
            ? 'Aguarde enquanto o adesivo é identificado'
            : 'Aproxime o celular do adesivo ProtoTag para iniciar'}
        </p>

        {/* Tap area */}
        {state === 'waiting' && (
          <button
            onClick={handleTap}
            className="glass-card p-6 w-full flex flex-col items-center gap-3 active:scale-[0.98] transition-transform"
          >
            <Smartphone className="w-6 h-6 text-primary" />
            <span className="text-sm font-medium text-foreground">
              Toque para simular leitura NFC
            </span>
            <span className="text-xs text-muted-foreground">
              Em produção, basta aproximar o dispositivo
            </span>
          </button>
        )}

        {state === 'success' && (
          <div className="flex items-center gap-2 text-sm text-clinical-green font-medium">
            <Check className="w-4 h-4" />
            Adesivo PT-2026-00847 identificado
          </div>
        )}
      </div>
    </div>
  );
}
