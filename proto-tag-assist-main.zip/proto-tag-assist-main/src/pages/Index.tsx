import { useAppState } from '@/lib/appState';
import NFCGate from './NFCGate';
import CalibrationScreen from './CalibrationScreen';
import Dashboard from './Dashboard';

export default function Index() {
  const { nfcConnected, calibrationComplete } = useAppState();

  if (!nfcConnected) return <NFCGate />;
  if (!calibrationComplete) return <CalibrationScreen />;
  return <Dashboard />;
}
