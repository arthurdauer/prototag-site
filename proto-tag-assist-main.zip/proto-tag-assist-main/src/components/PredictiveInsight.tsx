import { TrendingDown, Clock } from 'lucide-react';

export default function PredictiveInsight() {
  return (
    <div className="glass-card p-5 border-clinical-yellow/20">
      <div className="flex items-center gap-2 mb-3">
        <TrendingDown className="w-4 h-4 text-clinical-yellow" />
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Previsão Inteligente
        </p>
      </div>
      <p className="text-sm font-medium text-foreground">
        Indício de perda de adaptação em ~10 dias
      </p>
      <p className="text-xs text-muted-foreground mt-1">
        Baseado na tendência de desvio progressivo do padrão basal e crescimento do paciente.
      </p>
      <div className="flex items-center gap-1.5 mt-3 text-xs text-clinical-yellow font-medium">
        <Clock className="w-3.5 h-3.5" />
        Agendar reavaliação recomendado
      </div>
    </div>
  );
}
