import type { PatientProfile } from '@/lib/mockData';

interface CalibrationCardProps {
  patient: PatientProfile;
}

export default function CalibrationCard({ patient }: CalibrationCardProps) {
  const progress = (patient.calibrationDay / 7) * 100;

  return (
    <div className="glass-card p-6">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Calibração
        </p>
        <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-clinical-blue-light text-clinical-blue">
          Em progresso
        </span>
      </div>
      <p className="text-2xl font-bold text-foreground mt-2">
        Dia {patient.calibrationDay} de 7
      </p>
      <p className="text-sm text-muted-foreground mt-1">
        Aprendendo padrão do paciente
      </p>
      <div className="mt-4 w-full bg-muted rounded-full h-2 overflow-hidden">
        <div
          className="h-full rounded-full bg-clinical-blue transition-all duration-700"
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {['Ativo', 'Repouso', 'Sem uso'].map((label, i) => (
          <div key={label} className="text-center p-2 bg-secondary rounded-lg">
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="text-sm font-semibold text-foreground mt-0.5">
              {i === 0 ? '62%' : i === 1 ? '30%' : '8%'}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
