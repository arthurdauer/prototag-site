import { useState } from 'react';
import { Nfc, Check, Loader2 } from 'lucide-react';

type NFCState = 'idle' | 'reading' | 'success' | 'error';

export default function NFCReader() {
  const [state, setState] = useState<NFCState>('idle');

  const handleRead = () => {
    setState('reading');
    setTimeout(() => {
      setState('success');
      setTimeout(() => setState('idle'), 2500);
    }, 1500);
  };

  return (
    <button
      onClick={handleRead}
      disabled={state === 'reading'}
      className={`glass-card p-4 w-full flex items-center gap-3 transition-all active:scale-[0.98] ${
        state === 'success' ? 'border-clinical-green/30 bg-clinical-green-light' : ''
      }`}
    >
      <div
        className={`w-10 h-10 rounded-full flex items-center justify-center ${
          state === 'success'
            ? 'bg-clinical-green text-success-foreground'
            : state === 'reading'
            ? 'bg-clinical-blue text-primary-foreground animate-pulse'
            : 'bg-primary text-primary-foreground'
        }`}
      >
        {state === 'reading' ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : state === 'success' ? (
          <Check className="w-5 h-5" />
        ) : (
          <Nfc className="w-5 h-5" />
        )}
      </div>
      <div className="text-left">
        <p className="text-sm font-medium text-foreground">
          {state === 'reading'
            ? 'Lendo adesivo...'
            : state === 'success'
            ? 'Leitura realizada com sucesso'
            : 'Ler Adesivo NFC'}
        </p>
        <p className="text-xs text-muted-foreground">
          {state === 'idle' ? 'Aproxime o dispositivo do adesivo' : state === 'reading' ? 'Aguarde...' : 'Dados atualizados'}
        </p>
      </div>
    </button>
  );
}
