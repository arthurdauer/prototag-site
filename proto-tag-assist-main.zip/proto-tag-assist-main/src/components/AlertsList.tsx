import { AlertTriangle, AlertCircle, Info } from 'lucide-react';
import type { Alert } from '@/lib/mockData';

interface AlertsListProps {
  alerts: Alert[];
}

const iconMap = {
  critical: <AlertCircle className="w-4 h-4 text-clinical-red" />,
  warning: <AlertTriangle className="w-4 h-4 text-clinical-yellow" />,
  info: <Info className="w-4 h-4 text-clinical-blue" />,
};

const bgMap = {
  critical: 'bg-clinical-red-light border-clinical-red/20',
  warning: 'bg-clinical-yellow-light border-clinical-yellow/20',
  info: 'bg-clinical-blue-light border-clinical-blue/20',
};

export default function AlertsList({ alerts }: AlertsListProps) {
  if (alerts.length === 0) return null;

  return (
    <div className="space-y-2">
      <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground px-1">
        Alertas
      </p>
      {alerts.map(alert => (
        <div
          key={alert.id}
          className={`flex gap-3 p-3 rounded-xl border ${bgMap[alert.type]} ${
            alert.read ? 'opacity-60' : ''
          }`}
        >
          <div className="mt-0.5">{iconMap[alert.type]}</div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground">{alert.message}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{alert.detail}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
