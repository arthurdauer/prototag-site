import { Activity } from 'lucide-react';

interface PatternDeviation {
  region: string;
  deviation: string;
  trend: 'increasing' | 'stable' | 'decreasing';
  description: string;
}

const mockDeviations: PatternDeviation[] = [
  {
    region: 'Região anterior',
    deviation: '+18% vs baseline',
    trend: 'increasing',
    description: 'Desvio crescente na distribuição de carga',
  },
  {
    region: 'Região medial',
    deviation: '+9% vs baseline',
    trend: 'stable',
    description: 'Assimetria de carga persistente',
  },
];

export default function HotspotIndicator() {
  return (
    <div className="glass-card p-5">
      <div className="flex items-center gap-2 mb-3">
        <Activity className="w-4 h-4 text-clinical-yellow" />
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Desvios do Padrão Basal
        </p>
      </div>
      <div className="space-y-2">
        {mockDeviations.map(d => (
          <div
            key={d.region}
            className={`flex items-center justify-between p-3 rounded-lg ${
              d.trend === 'increasing' ? 'bg-clinical-yellow-light' : 'bg-secondary'
            }`}
          >
            <div>
              <p className="text-sm font-medium text-foreground">{d.region}</p>
              <p className="text-xs text-muted-foreground">{d.description}</p>
            </div>
            <span
              className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                d.trend === 'increasing'
                  ? 'bg-clinical-yellow/10 text-clinical-yellow'
                  : 'bg-muted text-muted-foreground'
              }`}
            >
              {d.deviation}
            </span>
          </div>
        ))}
      </div>
      <p className="text-xs text-muted-foreground mt-3">
        Desvios calculados em relação ao baseline individual do paciente.
      </p>
    </div>
  );
}
