import { useState } from 'react';
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip, ReferenceLine } from 'recharts';
import { mockReadings24h, mockReadings7d, mockReadings30d, mockReadings12m } from '@/lib/mockData';

type Period = '24h' | '7d' | '30d' | '12m';

const periodData: Record<Period, typeof mockReadings24h> = {
  '24h': mockReadings24h,
  '7d': mockReadings7d,
  '30d': mockReadings30d,
  '12m': mockReadings12m,
};

const periodLabels: Record<Period, string> = {
  '24h': '24 horas',
  '7d': 'Semana',
  '30d': 'Mês',
  '12m': 'Ano',
};

function formatTick(period: Period, timestamp: Date) {
  const d = new Date(timestamp);
  if (period === '24h') return `${d.getHours()}h`;
  if (period === '7d') return d.toLocaleDateString('pt-BR', { weekday: 'short' });
  if (period === '30d') return `${d.getDate()}/${d.getMonth() + 1}`;
  return d.toLocaleDateString('pt-BR', { month: 'short' });
}

// Sample data to avoid rendering thousands of points
function sampleData(data: typeof mockReadings24h, maxPoints: number) {
  if (data.length <= maxPoints) return data;
  const step = Math.ceil(data.length / maxPoints);
  return data.filter((_, i) => i % step === 0);
}

export default function IIPChart() {
  const [period, setPeriod] = useState<Period>('7d');
  const raw = periodData[period];
  const data = sampleData(raw, 80).map(r => ({
    time: r.timestamp.getTime(),
    iip: r.iip,
    label: formatTick(period, r.timestamp),
  }));

  return (
    <div className="glass-card p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Evolução do IIP
        </p>
        <div className="flex gap-1 bg-muted rounded-lg p-0.5">
          {(Object.keys(periodLabels) as Period[]).map(p => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`text-xs px-3 py-1 rounded-md transition-all ${
                period === p
                  ? 'bg-card text-foreground shadow-sm font-medium'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {periodLabels[p]}
            </button>
          ))}
        </div>
      </div>
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="iipGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(210, 70%, 50%)" stopOpacity={0.2} />
                <stop offset="95%" stopColor="hsl(210, 70%, 50%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="label"
              tick={{ fontSize: 10, fill: 'hsl(215, 10%, 50%)' }}
              axisLine={false}
              tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              domain={[0, 100]}
              tick={{ fontSize: 10, fill: 'hsl(215, 10%, 50%)' }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{
                background: 'hsl(0, 0%, 100%)',
                border: '1px solid hsl(214, 20%, 90%)',
                borderRadius: '8px',
                fontSize: 12,
              }}
              formatter={(value: number) => [`${value}`, 'IIP']}
            />
            <ReferenceLine y={70} stroke="hsl(152, 60%, 42%)" strokeDasharray="3 3" strokeOpacity={0.4} />
            <ReferenceLine y={40} stroke="hsl(38, 92%, 50%)" strokeDasharray="3 3" strokeOpacity={0.4} />
            <Area
              type="monotone"
              dataKey="iip"
              stroke="hsl(210, 70%, 50%)"
              strokeWidth={2}
              fill="url(#iipGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
