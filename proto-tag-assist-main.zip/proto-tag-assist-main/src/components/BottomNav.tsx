import { useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, User, Activity, FileText } from 'lucide-react';
import { useAppState } from '@/lib/appState';

const tabs = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/advanced', icon: Activity, label: 'Avançado' },
  { path: '/patient', icon: User, label: 'Paciente' },
  { path: '/reports', icon: FileText, label: 'Relatórios' },
];

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const { nfcConnected, calibrationComplete } = useAppState();

  // Hide nav when not connected or during calibration
  if (!nfcConnected || !calibrationComplete) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
      <div className="flex justify-around items-center h-16 max-w-lg mx-auto px-2">
        {tabs.map(tab => {
          const active = location.pathname === tab.path;
          return (
            <button
              key={tab.path}
              onClick={() => navigate(tab.path)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg transition-colors ${
                active
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <tab.icon className="w-5 h-5" strokeWidth={active ? 2.2 : 1.8} />
              <span className={`text-[10px] ${active ? 'font-semibold' : 'font-medium'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
      <div className="h-[env(safe-area-inset-bottom)]" />
    </nav>
  );
}
