import { getIipColor, getIipStatus, getIipTrend, type SensorReading } from '@/lib/mockData';

interface IIPScoreProps {
  score: number;
  readings: SensorReading[];
}

const colorMap = {
  green: {
    text: 'text-clinical-green',
    bg: 'bg-clinical-green-light',
    ring: 'ring-clinical-green/20',
  },
  yellow: {
    text: 'text-clinical-yellow',
    bg: 'bg-clinical-yellow-light',
    ring: 'ring-clinical-yellow/20',
  },
  red: {
    text: 'text-clinical-red',
    bg: 'bg-clinical-red-light',
    ring: 'ring-clinical-red/20',
  },
};

export default function IIPScore({ score, readings }: IIPScoreProps) {
  const color = getIipColor(score);
  const status = getIipStatus(score);
  const trend = getIipTrend(readings);
  const styles = colorMap[color];

  return (
    <div className="glass-card p-6">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Índice de Integridade Protética
        </p>
        <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${styles.bg} ${styles.text}`}>
          {status}
        </span>
      </div>
      <div className="flex items-end gap-3">
        <span className={`text-6xl font-bold tracking-tight ${styles.text}`}>
          {score}
        </span>
        <div className="flex flex-col mb-2">
          <span className={`text-2xl ${styles.text}`}>{trend}</span>
          <span className="text-xs text-muted-foreground">/100</span>
        </div>
      </div>
      <div className="mt-4 w-full bg-muted rounded-full h-2 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-700 ${
            color === 'green' ? 'bg-clinical-green' : color === 'yellow' ? 'bg-clinical-yellow' : 'bg-clinical-red'
          }`}
          style={{ width: `${score}%` }}
        />
      </div>
    </div>
  );
}
