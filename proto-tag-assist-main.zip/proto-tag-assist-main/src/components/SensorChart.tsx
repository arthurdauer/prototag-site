import { useState } from 'react';
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, ReferenceArea } from 'recharts';
import { mockReadings24h, mockReadings7d, mockReadings30d, mockReadings12m } from '@/lib/mockData';

type Period = '24h' | '7d' | '30d' | '12m';

const periodData: Record<Period, typeof mockReadings24h> = {
  '24h': mockReadings24h,
  '7d': mockReadings7d,
  '30d': mockReadings30d,
  '12m': mockReadings12m,
};

const sensorColors = [
  'hsl(210, 70%, 50%)',
  'hsl(152, 60%, 42%)',
  'hsl(38, 92%, 50%)',
  'hsl(0, 72%, 51%)',
  'hsl(280, 60%, 50%)',
  'hsl(180, 60%, 40%)',
];

const sensorLabels = ['S1 - Anterior', 'S2 - Lateral', 'S3 - Posterior', 'S4 - Medial', 'S5 - Distal', 'S6 - Proximal'];

function sampleData(data: typeof mockReadings24h, maxPoints: number) {
  if (data.length <= maxPoints) return data;
  const step = Math.ceil(data.length / maxPoints);
  return data.filter((_, i) => i % step === 0);
}

export default function SensorChart() {
  const [period, setPeriod] = useState<Period>('24h');
  const raw = periodData[period];
  const sampled = sampleData(raw, 60);
  const data = sampled.map((r, idx) => {
    const obj: Record<string, number | string> = {
      time: r.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      index: idx,
      context: r.context,
    };
    r.sensors.forEach((v, i) => {
      obj[`s${i}`] = Math.round(v);
    });
    return obj;
  });

  // Find "off" regions for shading
  const offRegions: { start: number; end: number }[] = [];
  let offStart: number | null = null;
  sampled.forEach((r, i) => {
    if (r.context === 'off' && offStart === null) offStart = i;
    if (r.context !== 'off' && offStart !== null) {
      offRegions.push({ start: offStart, end: i - 1 });
      offStart = null;
    }
  });
  if (offStart !== null) offRegions.push({ start: offStart, end: sampled.length - 1 });

  const periods: Period[] = ['24h', '7d', '30d', '12m'];
  const periodLabels: Record<Period, string> = { '24h': '24h', '7d': 'Semana', '30d': 'Mês', '12m': 'Ano' };

  return (
    <div className="glass-card p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Dados Brutos dos Sensores
        </p>
        <div className="flex gap-1 bg-muted rounded-lg p-0.5">
          {periods.map(p => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`text-xs px-3 py-1 rounded-md transition-all ${
                period === p
                  ? 'bg-card text-foreground shadow-sm font-medium'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {periodLabels[p]}
            </button>
          ))}
        </div>
      </div>

      {/* Legend for off periods */}
      <div className="flex items-center gap-2 mb-2">
        <div className="w-3 h-3 rounded-sm bg-muted border border-border" />
        <span className="text-[10px] text-muted-foreground">Sem uso (prótese removida)</span>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
            {/* Shade off-periods */}
            {offRegions.map((region, i) => (
              <ReferenceArea
                key={i}
                x1={data[region.start]?.time}
                x2={data[region.end]?.time}
                fill="hsl(210, 15%, 93%)"
                fillOpacity={0.6}
              />
            ))}
            <XAxis
              dataKey="time"
              tick={{ fontSize: 9, fill: 'hsl(215, 10%, 50%)' }}
              axisLine={false}
              tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              domain={[0, 100]}
              tick={{ fontSize: 9, fill: 'hsl(215, 10%, 50%)' }}
              axisLine={false}
              tickLine={false}
              label={{ value: 'kPa', angle: -90, position: 'insideLeft', fontSize: 10, fill: 'hsl(215, 10%, 50%)' }}
            />
            <Tooltip
              contentStyle={{
                background: 'hsl(0, 0%, 100%)',
                border: '1px solid hsl(214, 20%, 90%)',
                borderRadius: '8px',
                fontSize: 11,
              }}
            />
            <Legend
              iconType="line"
              wrapperStyle={{ fontSize: 10, paddingTop: 8 }}
            />
            {sensorLabels.map((label, i) => (
              <Line
                key={i}
                type="monotone"
                dataKey={`s${i}`}
                name={label}
                stroke={sensorColors[i]}
                strokeWidth={1.5}
                dot={false}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
