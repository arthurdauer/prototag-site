// Simulated sensor and IIP data for ProtoTag

export interface SensorReading {
  timestamp: Date;
  sensors: number[]; // 6 sensors, values 0-100 (kPa)
  iip: number;
  context: 'active' | 'rest' | 'off';
}

export interface PatientProfile {
  id: string;
  name: string;
  age: number;
  side: 'esquerdo' | 'direito';
  startDate: Date;
  calibrationComplete: boolean;
  calibrationDay: number;
  stickerSerial: string;
}

export interface Alert {
  id: string;
  type: 'warning' | 'critical' | 'info';
  message: string;
  detail: string;
  timestamp: Date;
  read: boolean;
}

export const mockPatient: PatientProfile = {
  id: '1',
  name: 'Lucas M. Silva',
  age: 9,
  side: 'direito',
  startDate: new Date(2026, 2, 1),
  calibrationComplete: true,
  calibrationDay: 7,
  stickerSerial: 'PT-2026-00847',
};

export const mockCalibrationPatient: PatientProfile = {
  ...mockPatient,
  id: '2',
  name: 'Ana P. Costa',
  age: 7,
  side: 'esquerdo',
  startDate: new Date(2026, 3, 8),
  calibrationComplete: false,
  calibrationDay: 3,
};

function generateReadings(hours: number, baseIip: number): SensorReading[] {
  const readings: SensorReading[] = [];
  const now = new Date();
  const totalSlots = hours * 4; // 15-min intervals

  for (let i = totalSlots; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 15 * 60 * 1000);
    const hour = timestamp.getHours();
    const isNight = hour < 6 || hour > 22;
    
    // Determine context: night = off/rest, day = mostly active with some rest/off
    let context: SensorReading['context'];
    if (isNight) {
      context = 'off'; // prosthesis not worn at night
    } else {
      const r = Math.random();
      if (r < 0.10) context = 'off';      // 10% not wearing during day
      else if (r < 0.25) context = 'rest'; // 15% resting with prosthesis
      else context = 'active';              // 75% active use
    }

    // Long-term decay: IIP decreases over time (child growth → worse fit)
    // decay rate: lose ~0.02 points per 15-min slot for long periods
    const decayRate = 0.015;
    const decay = i * decayRate;
    
    // Short-term noise: small oscillations
    const noise = (Math.random() - 0.5) * 6;
    
    // Small short-term recovery possible, but overall trend is down
    const shortTermRecovery = Math.sin(i * 0.05) * 2;
    
    const iip = Math.max(0, Math.min(100, baseIip - decay + noise + shortTermRecovery));

    // Sensor pressures
    let sensors: number[];
    if (context === 'off') {
      // No pressure when prosthesis is off - values near zero
      sensors = Array(6).fill(0).map(() => Math.random() * 2);
    } else {
      const basePressures = [42, 38, 55, 48, 35, 40];
      const activityBoost = context === 'active' ? 10 : -5;
      sensors = basePressures.map(bp => {
        const variation = (Math.random() - 0.5) * 15;
        return Math.max(0, Math.min(100, bp + variation + activityBoost));
      });
    }

    readings.push({ timestamp, sensors, iip: Math.round(iip), context });
  }
  return readings;
}

export const mockReadings24h = generateReadings(24, 82);
export const mockReadings7d = generateReadings(24 * 7, 85);
export const mockReadings30d = generateReadings(24 * 30, 88);
export const mockReadings12m = generateReadings(24 * 365, 92);

export const currentIip = mockReadings24h[mockReadings24h.length - 1]?.iip ?? 82;

// Pattern-based clinical alerts (not hotspot-based)
export const mockAlerts: Alert[] = [
  {
    id: '1',
    type: 'warning',
    message: 'Desvio progressivo do padrão basal',
    detail: 'Distribuição de carga apresenta desvio crescente em relação ao baseline dos últimos 14 dias.',
    timestamp: new Date(2026, 3, 10, 14, 30),
    read: false,
  },
  {
    id: '2',
    type: 'info',
    message: 'Mudança persistente na distribuição de carga',
    detail: 'Assimetria de carga aumentou 8% nos últimos 7 dias. Monitorar evolução.',
    timestamp: new Date(2026, 3, 9, 10, 0),
    read: false,
  },
  {
    id: '3',
    type: 'critical',
    message: 'Indício de perda de adaptação da prótese',
    detail: 'Padrão de pressão anormal sustentado por 5 dias. Previsão de queda crítica em ~10 dias.',
    timestamp: new Date(2026, 3, 8, 16, 45),
    read: true,
  },
];

export function getIipColor(iip: number): 'green' | 'yellow' | 'red' {
  if (iip >= 70) return 'green';
  if (iip >= 40) return 'yellow';
  return 'red';
}

export function getIipStatus(iip: number): string {
  if (iip >= 70) return 'Estável';
  if (iip >= 40) return 'Atenção';
  return 'Crítico';
}

export function getIipTrend(readings: SensorReading[]): '↑' | '↓' | '→' {
  if (readings.length < 10) return '→';
  const recent = readings.slice(-10).reduce((a, b) => a + b.iip, 0) / 10;
  const older = readings.slice(-20, -10).reduce((a, b) => a + b.iip, 0) / 10;
  const diff = recent - older;
  if (diff > 2) return '↑';
  if (diff < -2) return '↓';
  return '→';
}
