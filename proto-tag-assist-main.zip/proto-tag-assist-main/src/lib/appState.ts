import { useState, useEffect } from 'react';

let _nfcConnected = false;
let _calibrationComplete = true; // default to mock patient who is calibrated
let _calibrationDay = 7;
const listeners = new Set<() => void>();

function notify() {
  listeners.forEach(fn => fn());
}

export function useAppState() {
  const [, forceUpdate] = useState(0);

  useEffect(() => {
    const cb = () => forceUpdate(n => n + 1);
    listeners.add(cb);
    return () => { listeners.delete(cb); };
  }, []);

  return {
    nfcConnected: _nfcConnected,
    calibrationComplete: _calibrationComplete,
    calibrationDay: _calibrationDay,
    setNfcConnected: (v: boolean) => { _nfcConnected = v; notify(); },
    setCalibrationComplete: (v: boolean) => { _calibrationComplete = v; notify(); },
    setCalibrationDay: (d: number) => { _calibrationDay = d; notify(); },
  };
}
